<?php
$bd_host="localhost";
$bd_usuario="root";
$bd_pass="root";
$bd_base="utiedu_simons";
//$bd_host = "localhost";
//$bd_usuario = "root";
//$bd_pass = "sistemas";
//$bd_base = "paciente";
//$bd_port=""; // este vacio
?>