<?php
$servidor = 'localhost';
$bd = 'utiedu_simons';
$usuario_mysql = 'root';
$clave_mysql = 'root';
$administrador = '7777777';
$nombre_centro = 'Universidad Tecnológica "Indoamérica"';
$dir_centro = 'Ambato';
$telefono_centro = '032421452';
$fax_centro = '032421713';
$mail_centro = 'info@uti.edu.ec';
$web_centro = 'http://simons.uti.edu.ec';
$idioma = 'castellano.php';
?>